import { Component, OnInit } from '@angular/core';
import { User } from '@app/_models/user';

import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

import { AccountService, SessionService } from '@app/_services';

import { ShopService } from '@app/_services/shop.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-account-setting',
  templateUrl: './account-setting.component.html',
  styleUrls: ['./account-setting.component.css']
})
export class AccountSettingComponent implements OnInit {
  UserDetails: any;
  currentuser:any;

  modalOptions: NgbModalOptions = {
    // backdrop: 'static',
    backdropClass: 'customBackdrop'
  };

  constructor(private  accountService:AccountService,
    private toastrService: ToastrService,
    private shopService: ShopService,
    private sessionService: SessionService) { }

  ngOnInit(): void {
    this.currentuser=this.sessionService.getSessionObject("user");
    console.log(this.currentuser);
      this.accountService.getCustomer(this.currentuser.customerId).subscribe((response)=>{
        this.UserDetails=response.result.customers[0];
        console.log(this.UserDetails);
      });
     //this.accountService.getLoyalityPoints().subscribe((response)=>{
   //  console.log(response);
   //});
  }

}
